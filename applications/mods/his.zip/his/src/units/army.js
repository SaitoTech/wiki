
    this.importArmyLeader('suleiman', {
      type		:	"suleiman" ,
      name		: 	"Suleiman",
      personage		:	true,
      army_leader	:	true,
      img		:	"Suleiman.svg",
      battle_rating	:	2,
      command_value	:	12,
    });
 
    this.importArmyLeader('ibrahim-pasha', {
      type		:	"ibrahim-pasha" ,
      name		: 	"Ibrahim Pasha",
      personage		:	true,
      army_leader	:	true,
      img		:	"Ibrahim.svg",
      battle_rating	:	1,
      command_value	:	6,
    });
 
  
    this.importArmyLeader('charles-v', {
      type		:	"charles-v" ,
      name		: 	"Charles V",
      personage		:	true,
      army_leader	:	true,
      img		:	"Charles_V.svg",
      battle_rating	:	2,
      command_value	:	10,
    });
 
    this.importArmyLeader('duke-of-alva', {
      type		:	"duke-of-alva" ,
      name		: 	"Duke of Alva",
      personage		:	true,
      army_leader	:	true,
      img		:	"Duke_of_Alva.svg",
      battle_rating	:	1,
      command_value	:	6,
    });
 
    this.importArmyLeader('ferdinand', {
      type		:	"ferdinand" ,
      name		: 	"Ferdinand",
      personage		:	true,
      army_leader	:	true,
      img		:	"Ferdinand.svg",
      battle_rating	:	1,
      command_value	:	6,
    });
 
    this.importArmyLeader('henry-viii', {
      type		:	"henry-viii" ,
      name		: 	"Henry VIII",
      personage		:	true,
      army_leader	:	true,
      img		:	"Henry_VIII.svg",
      battle_rating	:	1,
      command_value	:	8,
    });
 
    this.importArmyLeader('charles-brandon', {
      type		:	"charles-brandon" ,
      name		: 	"Charles Brandon",
      personage		:	true,
      army_leader	:	true,
      img		:	"Brandon.svg",
      battle_rating	:	1,
      command_value	:	6,
    });
 
    this.importArmyLeader('francis-i', {
      type		:	"francis-i" ,
      name		: 	"Francis I",
      personage		:	true,
      army_leader	:	true,
      img		:	"Francis_I.svg",
      battle_rating	:	1,
      command_value	:	8,
    });

    this.importArmyLeader('henry-ii', {
      type		:	"henry-ii" ,
      name		: 	"Henry II",
      personage		:	true,
      army_leader	:	true,
      img		:	"Henry_II.svg",
      battle_rating	:	0,
      command_value	:	8,
    });
 
    this.importArmyLeader('montmorency', {
      type		:	"montmorency" ,
      name		: 	"Montmorency",
      personage		:	true,
      army_leader	:	true,
      img		:	"Montmorency.svg",
      battle_rating	:	1,
      command_value	:	6,
    });
 
    this.importArmyLeader('andrea-doria', {
      type		:	"andrea-doria" ,
      name		: 	"Andrea Doria",
      personage		:	true,
      army_leader	:	true,
      img		:	"Andrea_Doria.svg",
      battle_rating	:	2,
      command_value	:	0,
    });

    this.importArmyLeader('maurice-of-saxony', {
      type		:	"maurice-of-saxony" ,
      name		: 	"Maurice of Saxony",
      personage		:	true,
      army_leader	:	true,
      img		:	"Maurice_Protestant.svg", // "Maurice_Hapsburg.svg"
      battle_rating	:	1,
      command_value	:	6,
    });

    this.importArmyLeader('dudley', {
      type              :       "dudley" ,
      name              :       "Dudley",
      personage         :       true,
      army_leader       :       true,
      img               :       "Dudley.svg",
      battle_rating     :       0,
      command_value     :       6,
    });

    this.importArmyLeader('john-frederick', {
      type              :       "john-frederick" ,
      name              :       "John Frederick",
      personage         :       true,
      army_leader       :       true,
      img               :       "John_Frederick.svg",
      battle_rating     :       0,
      command_value     :       6,
    });

    this.importArmyLeader('philip-hesse', {
      type              :       "philip-hesse" ,
      name              :       "Philip Hesse",
      personage         :       true,
      army_leader       :       true,
      img               :       "Philip_Hesse.svg",
      battle_rating     :       0,
      command_value     :       6,
    });

    this.importArmyLeader('renegade', {
      type              :       "renegade" ,
      name              :       "Renegade Leader",
      personage         :       true,
      army_leader       :       true,
      img               :       "Renegade.svg",
      battle_rating     :       1,
      command_value     :       6,
    });


