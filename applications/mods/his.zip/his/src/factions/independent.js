
    this.importFaction('faction11', {
      id                :       "faction11" ,
      key               :       "independent" ,
      name              :       "Independent",
      nickname          :       "Independent",
    });


