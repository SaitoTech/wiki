INTRODUCTION

This is an implement of PATHS OF GLORY written for the open source Saito Game Engine.

This code is released under an open source license for use with teh open source Saito Game Engine. If you are a player or developer who enjoys playing around with this implementation, please respect the goodwill shown by GMT Games and purchase a copy of the game. Likewise, if you make this demo available for play on a public server, please make sure that any players you support can fulfill these conditions by making it easy for them to purchase commercial copies of the game.

GMT GAMES:
https://www.amazon.com/Paths-of-Glory-5th-Printing/dp/B00UKJIEBI

AMAZON:
https://www.amazon.com/Paths-of-Glory-5th-Printing/dp/B00UKJIEBI
