
    this.importFaction('faction8', {
      id                :       "faction8" ,
      key               :       "hungary" ,
      name              :       "Hungary",
      nickname          :       "Hungary",
    });


