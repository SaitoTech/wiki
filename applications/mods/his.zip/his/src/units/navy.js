
    this.importNavyLeader('barbarossa', {
      type		:	"barbarossa" ,
      name		: 	"Barbarossa",
      personage		:	true,
      navy_leader	:	true,
      img		:	"Barbarossa.svg",
      battle_rating	:	2,
      piracy_rating	:	1,
    });
 
    this.importNavyLeader('dragut', {
      type		:	"dragut" ,
      name		: 	"Dragut",
      personage		:	true,
      navy_leader	:	true,
      img		:	"Dragut.svg",
      battle_rating	:	1,
      piracy_rating	:	2,
    });
 
    this.importNavyLeader('andrea-doria', {
      type		:	"andrea-doria" ,
      name		: 	"Andrea Doria",
      personage		:	true,
      navy_leader	:	true,
      img		:	"Andrea_Doria.svg",
      battle_rating	:	2,
      piracy_rating	:	0,
    });
 

