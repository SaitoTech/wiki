
      this.importReformer('calvin-reformer', {
           type              :       "calvin-reformer" ,
           name              :       "John Calvin",
           reformer          :       true,
           img               :       "CalvinReformer.svg",
	   spacekey	     :	     "geneva",
      });

      this.importReformer('cranmer-reformer', {
           type              :       "cranmer-reformer" ,
           name              :       "Thomas Cranmer ",
           reformer          :       true,
           img               :       "CranmerReformer.svg",
	   spacekey	     :	     "london",
      });

      this.importReformer('luther-reformer', {
           type              :       "luther-reformer" ,
           name              :       "Martin Luther",
           reformer          :       true,
           img               :       "LutherReformer.svg",
	   spacekey	     :	     "wittenberg",
      });

      this.importReformer('zwingli-reformer', {
           type              :       "zwingli-reformer" ,
           name              :       "Huldrych Zwingli",
           reformer          :       true,
           img               :       "ZwingliReformer.svg",
	   spacekey	     :	     "zurich",
      });

