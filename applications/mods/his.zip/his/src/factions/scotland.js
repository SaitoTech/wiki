
    this.importFaction('faction10', {
      id                :       "faction10" ,
      key               :       "scotland" ,
      name              :       "Scotland",
      nickname          :       "Scotland",
    });


